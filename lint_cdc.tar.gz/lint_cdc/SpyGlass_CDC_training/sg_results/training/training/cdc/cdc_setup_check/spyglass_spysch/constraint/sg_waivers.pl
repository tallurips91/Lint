################################################################################
#This is an internally genertaed by spyglass to populate Waiver Info for Reports
#Note:Spyglass does not support any perl routine like "spyDecompileWaiverInfo"
#     The routine is purely for internal usage of spyglass
################################################################################


use SpyGlass;

spyClearWaiverHashInPerl(0);

spyComputeWaivedViolCount("totalWaivedViolationCount"=>'2',
                          "totalGeneratedCount"=>'0',
                          "totalReportCount"=>'0'
                         );

spyDecompileWaiverInfo("waive_cmd_id"=>'1',
                       "waiverCmd"=>'q%waive  -exact  -du "training" -rule "DetectTopDesignUnits" -msg "Module training is a top level design unit" -comment "I only ever have 1 top level unit."%',
                       "-du"=>'"training"',
                       "-rule"=>'"DetectTopDesignUnits"',
                       "-exact"=>'1',
                       "-msg"=>'q%Module training is a top level design unit%',
                       "-comment"=>'"I only ever have 1 top level unit."',
                       "violations_waived"=>'2',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"training.awl"',
                       "waiverline"=>'15'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'2',
                       "waiverCmd"=>'q%waive  -exact  -rule "ElabSummary" -comment "Created by seano on 1-Nov-2012 18:44:55"%',
                       "-rule"=>'"ElabSummary"',
                       "-exact"=>'1',
                       "-comment"=>'"Created by seano on 1-Nov-2012 18:44:55"',
                       "violations_waived"=>'1',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"training.awl"',
                       "waiverline"=>'16'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'3',
                       "waiverCmd"=>'q%waive  -exact  -rule "Setup_clock01" -comment "Created by seano on 1-Nov-2012 18:55:51"%',
                       "-rule"=>'"Setup_clock01"',
                       "-exact"=>'1',
                       "-comment"=>'"Created by seano on 1-Nov-2012 18:55:51"',
                       "violations_waived"=>'',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"training.awl"',
                       "waiverline"=>'17'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'4',
                       "waiverCmd"=>'q%waive  -exact  -ip "rule_Ac_sync01" -rule "Ac_sync01" -comment "Created by seano on 2-Nov-2012 12:18:06"%',
                       "-ip"=>'"rule_Ac_sync01"',
                       "-rule"=>'"Ac_sync01"',
                       "-exact"=>'1',
                       "-comment"=>'"Created by seano on 2-Nov-2012 12:18:06"',
                       "violations_waived"=>'',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"training.awl"',
                       "waiverline"=>'18'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'5',
                       "waiverCmd"=>'q%waive  -exact  -ip "clk_switch" -rule "Ac_unsync01" -comment "Created by seano on 12-Nov-2012 12:38:35"%',
                       "-ip"=>'"clk_switch"',
                       "-rule"=>'"Ac_unsync01"',
                       "-exact"=>'1',
                       "-comment"=>'"Created by seano on 12-Nov-2012 12:38:35"',
                       "violations_waived"=>'',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"training.awl"',
                       "waiverline"=>'19'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'6',
                       "waiverCmd"=>'q%waive -file_line "../RTL/sync2s.sv" 10 -rule "Ac_unsync01" -comment "RTL_PRAGMA: Waiver pragma in HDL source"%',
                       "-file_line"=>'"../RTL/sync2s.sv" 10',
                       "-rule"=>'"Ac_unsync01"',
                       "-comment"=>'"RTL_PRAGMA: Waiver pragma in HDL source"',
                       "violations_waived"=>'',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"../sg_results/training/training/cdc/cdc_setup_check/spyglass_spysch/waiver/pragma2Waiver.swl"',
                       "waiverline"=>'10'
                      );

spyWaiversDataCount("totalWaivers"=>'6',
"totalWaiversApplied"=>'6',
"totalWaiversWithRegExp"=>'0',
"totalWaiversWithRuleSpecified"=>'6',
"totalWaiversWithIpSpecified"=>'2',
"totalWaiversWithFileLine"=>'1',
"totalWaiverForIp"=>[' clk_switch ',0,' rule_Ac_sync01 ',0,]
                         );

spyProhibitWaiverRules(                         );

spySetWaivedViolationNumberHash("");

1;
