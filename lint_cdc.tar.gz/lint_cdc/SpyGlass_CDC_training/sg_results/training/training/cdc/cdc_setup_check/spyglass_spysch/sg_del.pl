use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("../sg_results/training/training/cdc/cdc_setup_check/spyglass_spysch/sg_msgtag.txt");
1;