use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./lab-3/async_reset_no_sync/cdc/cdc_verify_struct/spyglass_spysch/sg_msgtag.txt");
1;