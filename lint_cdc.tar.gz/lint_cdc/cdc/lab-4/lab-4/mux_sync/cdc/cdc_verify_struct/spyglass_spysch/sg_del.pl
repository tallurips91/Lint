use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./lab-4/mux_sync/cdc/cdc_verify_struct/spyglass_spysch/sg_msgtag.txt");
1;