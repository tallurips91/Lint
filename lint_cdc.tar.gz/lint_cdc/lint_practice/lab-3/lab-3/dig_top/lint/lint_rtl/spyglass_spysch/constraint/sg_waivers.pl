################################################################################
#This is an internally genertaed by spyglass to populate Waiver Info for Reports
#Note:Spyglass does not support any perl routine like "spyDecompileWaiverInfo"
#     The routine is purely for internal usage of spyglass
################################################################################


use SpyGlass;

spyClearWaiverHashInPerl(0);

spyComputeWaivedViolCount("totalWaivedViolationCount"=>'9',
                          "totalGeneratedCount"=>'0',
                          "totalReportCount"=>'0'
                         );

spyDecompileWaiverInfo("waive_cmd_id"=>'1',
                       "waiverCmd"=>'q%waive  -du "clk_gate" -rule "InferLatch" -msg "Latch inferred for signal \'lat_en\' in module \'clk_gate\'" -comment "Created by dvf305ce19 on 22-Oct-2020 09:46:13" --on_the_fly_compat_check %',
                       "-du"=>'"clk_gate"',
                       "-rule"=>'"InferLatch"',
                       "-msg"=>'q%Latch inferred for signal \'lat_en\' in module \'clk_gate\'%',
                       "-comment"=>'"Created by dvf305ce19 on 22-Oct-2020 09:46:13"',
                       "violations_waived"=>'54',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"./lint_dig_top_waivers.awl"',
                       "waiverline"=>'1'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'2',
                       "waiverCmd"=>'q%waive  -rule "STARC05-2.11.3.1" -comment "Created by dvf305ce19 on 22-Oct-2020 09:50:27"%',
                       "-rule"=>'q%STARC05-2.11.3.1%',
                       "-comment"=>'"Created by dvf305ce19 on 22-Oct-2020 09:50:27"',
                       "violations_waived"=>'14 15 16',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"./lint_dig_top_waivers.awl"',
                       "waiverline"=>'2'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'3',
                       "waiverCmd"=>'q%waive  -rule "STARC05-1.4.3.4" -msg "Clock signal \'dig_top.clk_500khz\' used as a non-clock (Used with name \'dig_top.clk_500khz\')" -comment "Created by dvf305ce19 on 22-Oct-2020 09:52:47"%',
                       "-rule"=>'q%STARC05-1.4.3.4%',
                       "-msg"=>'q%Clock signal \'dig_top.clk_500khz\' used as a non-clock (Used with name \'dig_top.clk_500khz\')%',
                       "-comment"=>'"Created by dvf305ce19 on 22-Oct-2020 09:52:47"',
                       "violations_waived"=>'55',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"./lint_dig_top_waivers.awl"',
                       "waiverline"=>'3'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'4',
                       "waiverCmd"=>'q%waive  -rule "W287b" -comment "Created by dvf305ce19 on 22-Oct-2020 09:53:50"%',
                       "-rule"=>'"W287b"',
                       "-comment"=>'"Created by dvf305ce19 on 22-Oct-2020 09:53:50"',
                       "violations_waived"=>'5 6 7 8',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"./lint_dig_top_waivers.awl"',
                       "waiverline"=>'4'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'5',
                       "waiverCmd"=>'q%waive  -rule "UndrivenInTerm-ML" -comment "Created by dvf305ce19 on 22-Oct-2020 09:54:31"%',
                       "-rule"=>'q%UndrivenInTerm-ML%',
                       "-comment"=>'"Created by dvf305ce19 on 22-Oct-2020 09:54:31"',
                       "violations_waived"=>'',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"./lint_dig_top_waivers.awl"',
                       "waiverline"=>'5'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'6',
                       "waiverCmd"=>'q%waive  -rule "W287a" -comment "Created by dvf305ce19 on 22-Oct-2020 09:55:39"%',
                       "-rule"=>'"W287a"',
                       "-comment"=>'"Created by dvf305ce19 on 22-Oct-2020 09:55:39"',
                       "violations_waived"=>'',
                       "partial_violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"./lint_dig_top_waivers.awl"',
                       "waiverline"=>'6'
                      );

spyWaiversDataCount("totalWaivers"=>'6',
"totalWaiversApplied"=>'6',
"totalWaiversWithRegExp"=>'0',
"totalWaiversWithRuleSpecified"=>'6',
"totalWaiversWithIpSpecified"=>'0',
"totalWaiversWithFileLine"=>'0',
                         );

spyProhibitWaiverRules(                         );

spySetWaivedViolationNumberHash("");

1;
