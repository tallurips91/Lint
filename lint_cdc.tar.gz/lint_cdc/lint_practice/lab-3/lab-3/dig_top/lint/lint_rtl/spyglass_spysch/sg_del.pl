use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./lab-3/dig_top/lint/lint_rtl/spyglass_spysch/sg_msgtag.txt");
1;